package pocs.arquitetura.poc_wordtopdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocWordtopdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
